'use client';
import { useEffect } from 'react';
export default function Locale({lang}:{lang:'en'|'zh'}){useEffect(()=>{document.documentElement.lang=lang==='en'?'en-HK':'zh-Hant-HK';},[lang]);return null;}
